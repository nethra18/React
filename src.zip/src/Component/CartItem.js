import React from 'react'



export default class CartItem extends React.Component{
    state = {qtyt:1}
    render()
    {
        const{item} = this.props;
        return(
              
           <tr>
                        <td>{item.productName}</td>
                        <td>{item.productPrice}</td>
                        <td>
                            <input type="number"
                            value={this.state.qty}
                            onChange={(e)=> this.setState({qty: e.currentTarget.value})}/>
                         
                        </td>
                      <td>{item.productPrice * this.state.qty}</td>
                </tr>
        );
               

     
       

    }
}
