import React from 'react';
import { connect } from 'react-redux'


const Currency=(props)=>{
    const {codes,changeCurrency}= props;
    return(
<select onChange = {
    (e) => changeCurrency(e.currentTarget.value)}>
{codes.map(
    c=><option key={c} vaue={c}>
    {c}</option>
)}
</select>
    );
    
}
const mapDisptchToProps=(dispatch)=>({
changeCurrency:(c)=>dispatch()
});
export default connect(null,mapDisptchToProps)(Currency);