import React from 'react';
import Product from '../Component/Product';
//import CartItem from '../Component/CartItem';
import * as _ from 'lodash';
import { connect } from 'react-redux'
import addToCart from '../Store/Action/addToCart'
 
class ProductList extends React.Component{


    state = {plist:[] };

     componentDidMount(){
         this.getData();
     }
//     render(){
        
//         const plist={
//             productId: 1000, productName: 'product 1',
//             productCost: 12000, productStock: true,
//            productImage: ''
//         }
        
//         return(

// plist.map(

// (p)=>   <Product 
// cCode={this.props.code}
// pData={p} key={p.productId}/>
//         )

//         )
// }
// }

getData(){
    const url = 'https://raw.githubusercontent.com/mdmoin7/Random-Products-Json-Generator/master/products.json'
    fetch(url).then(
        response => response.json()
    ).then(
        data=>{
        const list=_.chunk(data,10);
        console.log(list);
        
        this.setState({plist: list(10)}) 
        }
        ).catch(
        err => 
        console.log('error',err)
    );
}
render(){

return(
    this.state.plist.map(
        (p)=><Product
        cCode={this.props.code}
        pData={p} key={p.productId}
        addToCart={(data)=>{
            this.props.history.push(data)
            this.props.history.push('/Cart')
        }
        
    }
    />  

 
 
    )
)
}
}
 const mapStateToProps=(state)=>({
    code: state.code
});
 const mapDispatchToProps=(dispatch)=>({
    addToCart:(p)=>dispatch(addToCart(p))
});
//connect(what to connect)(component)
export default connect(mapStateToProps,mapDispatchToProps)(ProductList);