import React from 'react'
import CartItem from '../Component/CartItem'
import { connect } from 'react-redux'
class Cart extends React.Component{
    
    render(){
        const {cartData} = this.props;
        console.log(cartData)
        return(
            <table>
            {
               cartData.map(
                   item =><CartItem 
                   item={item}
                   key={item.productId} />
               )
               }
            </table>

        );
    }
}
const mapStateToProps=(state)=>({
    cartData:state.cart
});
export default connect(mapStateToProps)(Cart);
