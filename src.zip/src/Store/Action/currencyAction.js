
export const changeCurrency=(code)=>
{
    type:'UPDATE_CURRENCY'
    code: code 
}