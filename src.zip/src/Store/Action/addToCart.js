import React from 'react'

class addToCart extends React.Component{
    render(){
        return{
           
        }
    }
}




export default addToCart;