import  {UPDATE_CURRENCY} from "../actions/currencyAction"

export const currencyReducer =(state='INR',action)=>{
    switch(action.type){
        case UPDATE_CURRENCY:
        return action.code;
        default:
         return state;
    }

}