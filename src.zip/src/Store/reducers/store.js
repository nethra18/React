import { createStore} from 'redux'

import { currencyReducer} from './reduers/currencyReducer'

import { cartReducer} from './reduers/cartReducer'


const reduce=combineReducers({
    code:currencyReducer,
    cart:cartReducer
});

const store=createStore(reducer,
    window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
)


export default store;