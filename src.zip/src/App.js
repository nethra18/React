import React, { Component } from 'react';
import ProductList from './Container/ProductList';
import Currency from './Component/Currency';
import Cart from './Container/Cart'


// import Demo from './Demo';

class App extends Component {
  state={
  CurrencyCode:'INR',
  cartItem:[]
};
addItem(i){
  const items=this.state.cartItem;
  items.push(i);
  this.setState({cartItem: items})
}
render() {
  const currencies = ['INR','USD','EUR'];
  return (
   <center> <div className="App">
    <Currency 
    codes={currencies}
    changeCurrency={
      (code)=>this.setState({ CurrencyCode:code})

    }
    />  
      <ProductList code={this.state.CurrencyCode}
      sendToApp={(item)=>this.addItem(item)}/>
{/* 
      //here we are pushing item into cart// */}
      <Cart cartData={this.state.cartItem}/>
    </div></center>
  );
}
}

export default App;