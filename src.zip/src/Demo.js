import React from 'react';
class Demo extends React.Component{
    render(){
        // const name='hanamant';
        return(
            <div>
            <h1></h1>
            <p></p>
            <p>hello from name</p>
            </div>
        );
    }
}
export default Demo;